/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = true;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (Sec)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.65642994241843, "KoPercent": 1.3435700575815739};
    var dataset = [
        {
            "label" : "Failure",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "Success",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9415929203539823, 2000, 3000, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/logout"], "isController": false}, {"data": [0.6666666666666666, 2000, 3000, "SignOut"], "isController": true}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/logo-topbar.gif"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/my\/account\/update?form"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/dogs_icon.gif"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/my\/orders"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/cart"], "isController": false}, {"data": [0.95, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/splash.gif"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-27"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/products\/AV-SB-02"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/my\/orders\/create"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/login"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T13_Click_BookedOrder-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/reptiles_icon.gif"], "isController": false}, {"data": [0.5, 2000, 3000, "JPS00_T01_HomePage_Launch-0"], "isController": false}, {"data": [0.9166666666666666, 2000, 3000, "JPS01_T04_Select_A_Sub_Pet-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/categories\/FISH"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T10_Submit-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/categories\/CATS"], "isController": false}, {"data": [0.95, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/birds_icon.gif"], "isController": false}, {"data": [0.8333333333333334, 2000, 3000, "JPS01_T03_Select_A_Pet"], "isController": true}, {"data": [0.16666666666666666, 2000, 3000, "JPS01_T08_Login"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T12_Click_MyOrders"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T12_Click_MyOrders-0"], "isController": false}, {"data": [0.9166666666666666, 2000, 3000, "JPS01_T07_Proceed_to_Checkout"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T09_EnterDetails_and_Continue-0"], "isController": false}, {"data": [0.95, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/fish_icon.gif"], "isController": false}, {"data": [0.8333333333333334, 2000, 3000, "JPS01_T03_Select_A_Pet-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-1"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-19"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/categories\/DOGS"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T05_Select_A_Sub_Pet_Type-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-16"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-17"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-1"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/sm_fish.gif"], "isController": false}, {"data": [0.875, 2000, 3000, "JPS02_T04_Click_RegisterNow-0"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T11_Goto_MyAccount"], "isController": true}, {"data": [0.9743589743589743, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/sm_reptiles.gif"], "isController": false}, {"data": [0.9166666666666666, 2000, 3000, "JPS01_T07_Proceed_to_Checkout-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/css\/jpetstore.css"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/cats_icon.gif"], "isController": false}, {"data": [0.375, 2000, 3000, "JPS02_T05_EnterDetails_and_Save-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/products\/FI-FW-01"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-5"], "isController": false}, {"data": [0.5, 2000, 3000, "JPS00_T01_HomePage_Launch"], "isController": true}, {"data": [0.55, 2000, 3000, "JPS00_T02_EnterStore"], "isController": true}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/products\/FL-DLH-02"], "isController": false}, {"data": [0.9615384615384616, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/sm_cats.gif"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T13_Click_BookedOrder"], "isController": true}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-5"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/separator.gif"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/accounts\/create?form"], "isController": false}, {"data": [0.125, 2000, 3000, "JPS02_T06_Login-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/cart.gif"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/my\/orders\/create?form"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/sm_dogs.gif"], "isController": false}, {"data": [0.9743589743589743, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/images\/sm_birds.gif"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-27"], "isController": false}, {"data": [0.875, 2000, 3000, "JPS02_T03_Click_SignIN-0"], "isController": false}, {"data": [0.375, 2000, 3000, "JPS02_T05_EnterDetails_and_Save"], "isController": true}, {"data": [0.125, 2000, 3000, "JPS02_T06_Login"], "isController": true}, {"data": [0.9166666666666666, 2000, 3000, "JPS01_T04_Select_A_Sub_Pet"], "isController": true}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/products\/K9-CW-01"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T06_Add_to_Cart-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/login?error"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/products\/FI-SW-01"], "isController": false}, {"data": [0.6666666666666666, 2000, 3000, "SignOut-0"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/my\/orders\/1037"], "isController": false}, {"data": [0.5, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-19"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-16"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/my\/orders\/1038"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/catalog\/categories\/BIRDS"], "isController": false}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-17"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T09_EnterDetails_and_Continue"], "isController": true}, {"data": [0.55, 2000, 3000, "JPS00_T02_EnterStore-0"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T05_Select_A_Sub_Pet_Type"], "isController": true}, {"data": [1.0, 2000, 3000, "https:\/\/jpetstore.cfapps.io\/accounts\/create"], "isController": false}, {"data": [0.16666666666666666, 2000, 3000, "JPS01_T08_Login-0"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T10_Submit"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T11_Goto_MyAccount-0"], "isController": false}, {"data": [0.875, 2000, 3000, "JPS02_T04_Click_RegisterNow"], "isController": true}, {"data": [0.875, 2000, 3000, "JPS02_T03_Click_SignIN"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T06_Add_to_Cart"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1042, 14, 1.3435700575815739, 742.3243761996155, 43, 4321, 498.5, 984.0999999999999, 1013.4000000000001, 1249.2000000000003, 36.60764474423834, 191.93748572758574, 47.07865637296234], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "70th pct", "80th pct", "90th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["https:\/\/jpetstore.cfapps.io\/logout", 6, 0, 0.0, 244.16666666666669, 239, 250, 244.0, 247.7, 249.2, 250.0, 0.5740528128587831, 0.35598001578645233, 0.3864391982395714], "isController": false}, {"data": ["SignOut", 6, 0, 0.0, 2265.666666666667, 1742, 2688, 2344.0, 2496.1, 2612.4, 2688.0, 0.4925703965191692, 29.885089355348494, 5.544062602618833], "isController": true}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/logo-topbar.gif", 78, 0, 0.0, 568.1923076923076, 237, 1357, 255.5, 972.2, 1001.6, 1058.4, 3.5842293906810037, 15.639000896057347, 2.5653052051741567], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/my\/account\/update?form", 2, 0, 0.0, 247.0, 243, 251, 247.0, 251.0, 251.0, 251.0, 1.7873100983020553, 15.722743521000893, 1.2392482126899016], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/dogs_icon.gif", 20, 0, 0.0, 637.1999999999999, 240, 1071, 729.0, 987.1999999999999, 1001.6, 1045.8000000000002, 0.91726288754357, 1.0095266350210972, 0.645129620711796], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/my\/orders", 2, 0, 0.0, 256.5, 252, 261, 256.5, 261.0, 261.0, 261.0, 1.7953321364452424, 16.147469703770195, 1.2360440978456013], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/cart", 6, 0, 0.0, 248.33333333333334, 241, 254, 250.0, 252.0, 253.2, 254.0, 3.931847968545216, 27.636206790629096, 2.678827408256881], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/splash.gif", 20, 1, 5.0, 544.6999999999999, 43, 1251, 498.5, 505.0, 541.2, 1145.2000000000012, 0.9325313563668578, 31.932459959434887, 0.6213536566885812], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-27", 1, 0, 0.0, 246.0, 246, 246, 246.0, 246.0, 246.0, 246.0, 4.065040650406504, 2.171462144308943, 2.8423526422764227], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/products\/AV-SB-02", 1, 0, 0.0, 253.0, 253, 253, 253.0, 253.0, 253.0, 253.0, 3.952569169960474, 20.971004199604742, 2.7868700592885376], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/my\/orders\/create", 4, 0, 0.0, 261.0, 252, 272, 260.0, 269.0, 272.0, 272.0, 1.5100037750094375, 5.735507502831257, 1.4827234333710835], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/login", 24, 0, 0.0, 562.125, 236, 1575, 254.0, 907.5, 946.0, 1018.0, 2.230275996654586, 6.612238349131122, 1.7246160905120342], "isController": false}, {"data": ["JPS01_T13_Click_BookedOrder-0", 2, 0, 0.0, 1120.5, 735, 1506, 1120.5, 1506.0, 1506.0, 1506.0, 1.2911555842479019, 34.14249112330536, 8.842650500322788], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/reptiles_icon.gif", 20, 0, 0.0, 705.5999999999999, 241, 1175, 953.5, 989.3, 1063.0, 1131.9, 0.9503896597605018, 1.2325365900019007, 0.6721408121079643], "isController": false}, {"data": ["JPS00_T01_HomePage_Launch-0", 10, 0, 0.0, 2655.4, 1254, 4321, 2559.0, 3559.3, 4168.200000000001, 4320.5, 1.6900456312320433, 13.794337290856854, 1.873243936961298], "isController": false}, {"data": ["JPS01_T04_Select_A_Sub_Pet-0", 6, 0, 0.0, 1846.3333333333335, 1517, 2466, 1749.5, 1906.6, 2247.6000000000004, 2466.0, 2.3166023166023164, 52.97342543436294, 16.207921090733592], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/categories\/FISH", 2, 0, 0.0, 244.5, 239, 250, 244.5, 250.0, 250.0, 250.0, 7.722007722007723, 40.14086631274131, 5.308880308880309], "isController": false}, {"data": ["JPS01_T10_Submit-0", 2, 0, 0.0, 1632.5, 1503, 1762, 1632.5, 1762.0, 1762.0, 1762.0, 0.8399832003359933, 24.995652430701387, 6.440554782654347], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/categories\/CATS", 2, 0, 0.0, 255.0, 252, 258, 255.0, 258.0, 258.0, 258.0, 5.847953216374268, 28.046189692982455, 4.02046783625731], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/birds_icon.gif", 20, 1, 5.0, 571.5000000000001, 148, 1201, 257.5, 985.0, 1047.4, 1182.0000000000002, 0.9102908379227164, 1.0703917948659596, 0.6099126405261481], "isController": false}, {"data": ["JPS01_T03_Select_A_Pet", 6, 0, 0.0, 1779.1666666666667, 1484, 2220, 1709.5, 2009.8999999999999, 2149.2000000000003, 2220.0, 2.7027027027027026, 59.43922438063063, 18.48122536599099], "isController": true}, {"data": ["JPS01_T08_Login", 6, 4, 66.66666666666667, 2762.5, 2376, 3148, 2798.0, 3035.6, 3110.0, 3148.0, 1.3100436681222707, 31.468980281113538, 11.146458788209607], "isController": true}, {"data": ["JPS01_T12_Click_MyOrders", 2, 0, 0.0, 1472.5, 1453, 1492, 1472.5, 1492.0, 1492.0, 1492.0, 0.8669267446900737, 22.46982688556567, 6.043088968357174], "isController": true}, {"data": ["JPS01_T12_Click_MyOrders-0", 2, 0, 0.0, 1472.5, 1453, 1492, 1472.5, 1492.0, 1492.0, 1492.0, 0.8673026886383347, 22.479570956201215, 6.045709562012142], "isController": false}, {"data": ["JPS01_T07_Proceed_to_Checkout", 6, 0, 0.0, 1933.8333333333333, 1676, 2169, 1953.0, 1969.4, 2089.8, 2169.0, 1.7610801291458762, 38.88793981141767, 13.161666238626358], "isController": true}, {"data": ["JPS01_T09_EnterDetails_and_Continue-0", 2, 0, 0.0, 1617.5, 1480, 1755, 1617.5, 1755.0, 1755.0, 1755.0, 0.8421052631578948, 21.81167763157895, 6.329358552631579], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/fish_icon.gif", 20, 1, 5.0, 505.74999999999994, 235, 1198, 249.0, 894.9999999999999, 971.4, 1025.9, 0.950344499881207, 1.1021768828700402, 0.6358677090757899], "isController": false}, {"data": ["JPS01_T03_Select_A_Pet-0", 6, 0, 0.0, 1779.1666666666667, 1484, 2220, 1709.5, 2009.8999999999999, 2149.2000000000003, 2220.0, 2.7027027027027026, 59.43922438063063, 18.48122536599099], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-1", 1, 0, 0.0, 260.0, 260, 260, 260.0, 260.0, 260.0, 260.0, 3.8461538461538463, 22.036508413461537, 2.6968149038461537], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-19", 1, 0, 0.0, 264.0, 264, 264, 264.0, 264.0, 264.0, 264.0, 3.787878787878788, 21.669330018939394, 2.659653172348485], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/categories\/DOGS", 1, 0, 0.0, 254.0, 254, 254, 254.0, 254.0, 254.0, 254.0, 3.937007874015748, 22.118756151574804, 2.706692913385827], "isController": false}, {"data": ["JPS01_T05_Select_A_Sub_Pet_Type-0", 6, 0, 0.0, 1530.5, 1473, 1700, 1508.0, 1516.2, 1626.8000000000002, 1700.0, 2.165283291230603, 49.052970498015156, 15.186586521111513], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-16", 1, 0, 0.0, 246.0, 246, 246, 246.0, 246.0, 246.0, 246.0, 4.065040650406504, 23.35810467479675, 2.8582317073170733], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-17", 1, 0, 0.0, 253.0, 253, 253, 253.0, 253.0, 253.0, 253.0, 3.952569169960474, 22.684813488142293, 2.7791501976284585], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-1", 1, 0, 0.0, 245.0, 245, 245, 245.0, 245.0, 245.0, 245.0, 4.081632653061225, 2.1803252551020407, 2.845982142857143], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/sm_fish.gif", 78, 0, 0.0, 631.1666666666665, 233, 1504, 493.5, 977.3, 992.4, 1032.2, 3.5863717872086074, 3.257154064554692, 2.552829296749276], "isController": false}, {"data": ["JPS02_T04_Click_RegisterNow-0", 4, 0, 0.0, 1841.5, 1500, 2193, 1836.5, 2063.0, 2193.0, 2193.0, 1.3845621322256838, 35.119066934925584, 9.436385860159225], "isController": false}, {"data": ["JPS01_T11_Goto_MyAccount", 2, 0, 0.0, 1477.0, 1467, 1487, 1477.0, 1487.0, 1487.0, 1487.0, 0.8536064874093043, 21.95619264831413, 5.894386203585148], "isController": true}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/sm_reptiles.gif", 78, 2, 2.5641025641025643, 777.8333333333331, 234, 1783, 972.5, 988.3, 1006.0, 1113.8000000000002, 3.4712950600801067, 3.7399258038495775, 2.413330621384068], "isController": false}, {"data": ["JPS01_T07_Proceed_to_Checkout-0", 6, 0, 0.0, 1933.8333333333333, 1676, 2169, 1953.0, 1969.4, 2089.8, 2169.0, 1.7605633802816902, 38.876529030956576, 13.157804247359156], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/css\/jpetstore.css", 88, 0, 0.0, 432.81818181818176, 237, 1166, 254.5, 335.79999999999944, 966.6, 984.2, 3.795066413662239, 24.411535600310508, 2.6337033163705366], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/cats_icon.gif", 20, 0, 0.0, 566.5499999999998, 234, 1162, 251.0, 955.4, 1034.0, 1125.8000000000002, 0.9414422895876483, 0.9809755107324422, 0.6621354853135003], "isController": false}, {"data": ["JPS02_T05_EnterDetails_and_Save-0", 4, 0, 0.0, 2631.5, 2367, 3048, 2555.5, 2802.0, 3048.0, 3048.0, 0.9519276534983341, 21.13553627736792, 8.763498036649215], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/products\/FI-FW-01", 1, 0, 0.0, 259.0, 259, 259, 259.0, 259.0, 259.0, 259.0, 3.8610038610038613, 23.282909025096526, 2.7223093629343627], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-5", 1, 0, 0.0, 243.0, 243, 243, 243.0, 243.0, 243.0, 243.0, 4.11522633744856, 23.533950617283953, 2.8854809670781894], "isController": false}, {"data": ["JPS00_T01_HomePage_Launch", 10, 0, 0.0, 2655.4, 1254, 4321, 2559.0, 3559.3, 4168.200000000001, 4320.5, 1.6305233980107616, 13.308510313060493, 1.8072695866623185], "isController": true}, {"data": ["JPS00_T02_EnterStore", 10, 0, 0.0, 2478.9, 1762, 2910, 2465.5, 2634.1, 2685.4, 2888.8, 3.4364261168384878, 223.47307237972507, 36.871107173539514], "isController": true}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/products\/FL-DLH-02", 2, 0, 0.0, 251.0, 246, 256, 251.0, 256.0, 256.0, 256.0, 5.405405405405405, 32.87056587837838, 3.8165118243243246], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/sm_cats.gif", 78, 3, 3.8461538461538463, 827.7179487179485, 234, 1559, 972.0, 988.3, 995.6, 1131.5000000000002, 3.50372832629593, 3.4914894916224957, 2.3865727613197376], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog", 20, 0, 0.0, 254.25000000000003, 245, 273, 253.0, 257.1, 262.8, 269.6, 0.9144111192392099, 6.0519460526015, 0.5770434230980249], "isController": false}, {"data": ["JPS01_T13_Click_BookedOrder", 2, 0, 0.0, 1120.5, 735, 1506, 1120.5, 1506.0, 1506.0, 1506.0, 1.2911555842479019, 34.14249112330536, 8.842650500322788], "isController": true}, {"data": ["https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-5", 1, 0, 0.0, 249.0, 249, 249, 249.0, 249.0, 249.0, 249.0, 4.016064257028112, 2.1452999497991967, 2.8002635542168677], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/separator.gif", 78, 0, 0.0, 565.98717948718, 236, 1185, 259.0, 961.5, 984.6, 1015.3000000000001, 3.5855474855199043, 2.465063896294934, 2.5592455697802703], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/accounts\/create?form", 4, 0, 0.0, 249.5, 239, 257, 251.0, 254.0, 257.0, 257.0, 3.8498556304138596, 32.49255594321463, 2.6279776227141483], "isController": false}, {"data": ["JPS02_T06_Login-0", 4, 0, 0.0, 3470.0, 2947, 4080, 3426.5, 3762.0, 4080.0, 4080.0, 0.6984459577440195, 45.92486795006111, 9.446072332809498], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/cart.gif", 78, 0, 0.0, 548.8333333333334, 236, 1197, 253.0, 971.3, 990.6, 1005.3000000000001, 3.5847235626637253, 2.639532779539501, 2.5411539477917184], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/my\/orders\/create?form", 8, 0, 0.0, 246.75, 232, 252, 248.5, 250.3, 251.2, 252.0, 2.039255671679837, 5.050841989548815, 1.4482897336222278], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/sm_dogs.gif", 78, 0, 0.0, 628.897435897436, 235, 1234, 487.0, 986.0, 999.6, 1065.8000000000002, 3.5848883169408956, 3.3783371346171522, 2.5517733419891537], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/sm_birds.gif", 78, 2, 2.5641025641025643, 774.0897435897434, 237, 1533, 957.0, 983.3, 1003.2, 1193.4, 3.541269408880414, 3.3173685360483067, 2.4513820314628165], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/items\/EST-27", 1, 0, 0.0, 260.0, 260, 260, 260.0, 260.0, 260.0, 260.0, 3.8461538461538463, 22.010216346153847, 2.7005709134615383], "isController": false}, {"data": ["JPS02_T03_Click_SignIN-0", 4, 0, 0.0, 1801.25, 1558, 2156, 1745.5, 1964.5, 2156.0, 2156.0, 1.7152658662092624, 37.007196076329336, 11.69864922813036], "isController": false}, {"data": ["JPS02_T05_EnterDetails_and_Save", 4, 0, 0.0, 2631.5, 2367, 3048, 2555.5, 2802.0, 3048.0, 3048.0, 0.9517011658339282, 21.130507598738994, 8.761412978824648], "isController": true}, {"data": ["JPS02_T06_Login", 4, 0, 0.0, 3470.0, 2947, 4080, 3426.5, 3762.0, 4080.0, 4080.0, 0.6983240223463687, 45.916850340432966, 9.444423228002794], "isController": true}, {"data": ["JPS01_T04_Select_A_Sub_Pet", 6, 0, 0.0, 1846.3333333333335, 1517, 2466, 1749.5, 1906.6, 2247.6000000000004, 2466.0, 2.317497103128621, 52.99388639436076, 16.21418139242951], "isController": true}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/products\/K9-CW-01", 1, 0, 0.0, 244.0, 244, 244, 244.0, 244.0, 244.0, 244.0, 4.0983606557377055, 24.946369108606557, 2.8896644467213117], "isController": false}, {"data": ["JPS01_T06_Add_to_Cart-0", 6, 0, 0.0, 1806.1666666666667, 1723, 1947, 1755.5, 1914.8999999999999, 1940.6, 1947.0, 1.8598884066955983, 45.54456224814011, 14.212526154680718], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/login?error", 4, 0, 0.0, 248.0, 246, 253, 246.5, 250.0, 253.0, 253.0, 2.3923444976076556, 11.305813584031101, 1.873691686602871], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/products\/FI-SW-01", 1, 0, 0.0, 264.0, 264, 264, 264.0, 264.0, 264.0, 264.0, 3.787878787878788, 22.98251065340909, 2.670750473484848], "isController": false}, {"data": ["SignOut-0", 6, 0, 0.0, 2265.666666666667, 1742, 2688, 2344.0, 2496.1, 2612.4, 2688.0, 0.4925703965191692, 29.885089355348494, 5.544062602618833], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/my\/orders\/1037", 2, 0, 0.0, 260.0, 259, 261, 260.0, 261.0, 261.0, 261.0, 0.4445432318292954, 4.25723945599022, 0.32841499499888865], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/", 10, 0, 0.0, 2261.2, 976, 3900, 2136.0, 3136.3, 3750.8000000000006, 3900.0, 1.7658484901995408, 3.1643866987462475, 0.9639739316616633], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-19", 1, 0, 0.0, 235.0, 235, 235, 235.0, 235.0, 235.0, 235.0, 4.25531914893617, 2.2731050531914896, 2.975398936170213], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-16", 1, 0, 0.0, 253.0, 253, 253, 253.0, 253.0, 253.0, 253.0, 3.952569169960474, 2.1113821640316206, 2.7637104743083003], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/my\/orders\/1038", 2, 0, 0.0, 254.0, 244, 264, 254.0, 264.0, 264.0, 264.0, 0.42927666881305, 4.109569515990556, 0.31713652339557846], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/catalog\/categories\/BIRDS", 1, 0, 0.0, 252.0, 252, 252, 252.0, 252.0, 252.0, 252.0, 3.968253968253968, 19.046843998015873, 2.7320498511904763], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/cart?add&itemId=EST-17", 1, 0, 0.0, 240.0, 240, 240, 240.0, 240.0, 240.0, 240.0, 4.166666666666667, 2.225748697916667, 2.9134114583333335], "isController": false}, {"data": ["JPS01_T09_EnterDetails_and_Continue", 2, 0, 0.0, 1617.5, 1480, 1755, 1617.5, 1755.0, 1755.0, 1755.0, 0.8417508417508417, 21.802497632575758, 6.326694681186869], "isController": true}, {"data": ["JPS00_T02_EnterStore-0", 10, 0, 0.0, 2478.9, 1762, 2910, 2465.5, 2634.1, 2685.4, 2888.8, 3.431708991077557, 223.16631455902538, 36.82049480954015], "isController": false}, {"data": ["JPS01_T05_Select_A_Sub_Pet_Type", 6, 0, 0.0, 1530.5, 1473, 1700, 1508.0, 1516.2, 1626.8000000000002, 1700.0, 2.165283291230603, 49.052970498015156, 15.186586521111513], "isController": true}, {"data": ["https:\/\/jpetstore.cfapps.io\/accounts\/create", 4, 0, 0.0, 976.0, 875, 1066, 981.5, 1060.0, 1066.0, 1066.0, 1.971414489896501, 1.0550147856086742, 2.296774889107935], "isController": false}, {"data": ["JPS01_T08_Login-0", 6, 4, 66.66666666666667, 2762.5, 2376, 3148, 2798.0, 3035.6, 3110.0, 3148.0, 1.309757694826457, 31.462110824601613, 11.144025594848285], "isController": false}, {"data": ["JPS01_T10_Submit", 2, 0, 0.0, 1632.5, 1503, 1762, 1632.5, 1762.0, 1762.0, 1762.0, 0.8396305625524769, 24.985158873845506, 6.437850939336691], "isController": true}, {"data": ["JPS01_T11_Goto_MyAccount-0", 2, 0, 0.0, 1477.0, 1467, 1487, 1477.0, 1487.0, 1487.0, 1487.0, 0.8536064874093043, 21.95619264831413, 5.894386203585148], "isController": false}, {"data": ["JPS02_T04_Click_RegisterNow", 4, 0, 0.0, 1841.5, 1500, 2193, 1836.5, 2063.0, 2193.0, 2193.0, 1.3845621322256838, 35.119066934925584, 9.436385860159225], "isController": true}, {"data": ["JPS02_T03_Click_SignIN", 4, 0, 0.0, 1801.25, 1558, 2156, 1745.5, 1964.5, 2156.0, 2156.0, 1.7152658662092624, 37.007196076329336, 11.69864922813036], "isController": true}, {"data": ["JPS01_T06_Add_to_Cart", 6, 0, 0.0, 1806.1666666666667, 1723, 1947, 1755.5, 1914.8999999999999, 1940.6, 1947.0, 1.8598884066955983, 45.54456224814011, 14.212526154680718], "isController": true}]}, function(index, item){
        switch(index){
    // Errors pct, 3rd Column
            case 3:
                	item = item.toFixed(2) + '%';
                	break;
    // Average, 4th Column
            case 4:
					item = (item/1000).toFixed(2);
                	break;
	// Min, 5th Column
            case 5:
					item = (item/1000).toFixed(2);
                 	break;
	// Max, 6th Column
            case 6:
					item = (item/1000).toFixed(2);
                	break;
	// Median, 7th Column
            case 7:
					item = (item/1000).toFixed(2);
                	break;
    // 90th pct, 8th Column
            case 8:
					item = (item/1000).toFixed(2);
                	break;
	// 95th pct, 9th Column
            case 9:
				item = (item/1000).toFixed(2);
               	 break;
	// 99th pct, 10th Column
            case 10:
				item = (item/1000).toFixed(2);
				break;
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
               	item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Test failed: text expected to contain \\\/&lt;input type=&quot;submit&quot; name=&quot;continue&quot; value=&quot;Continue&quot;\\\/&gt;\\\/", 4, 28.571428571428573, 0.3838771593090211], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 9, 64.28571428571429, 0.8637236084452975], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket operation on nonsocket: connect", 1, 7.142857142857143, 0.09596928982725528], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1042, 14, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 9, "Test failed: text expected to contain \\\/&lt;input type=&quot;submit&quot; name=&quot;continue&quot; value=&quot;Continue&quot;\\\/&gt;\\\/", 4, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket operation on nonsocket: connect", 1, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/splash.gif", 20, 1, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/birds_icon.gif", 20, 1, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket operation on nonsocket: connect", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/fish_icon.gif", 20, 1, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/sm_reptiles.gif", 78, 2, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/sm_cats.gif", 78, 3, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/jpetstore.cfapps.io\/images\/sm_birds.gif", 78, 2, "Non HTTP response code: java.net.SocketException\/Non HTTP response message: Socket closed", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["JPS01_T08_Login-0", 6, 4, "Test failed: text expected to contain \\\/&lt;input type=&quot;submit&quot; name=&quot;continue&quot; value=&quot;Continue&quot;\\\/&gt;\\\/", 4, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
