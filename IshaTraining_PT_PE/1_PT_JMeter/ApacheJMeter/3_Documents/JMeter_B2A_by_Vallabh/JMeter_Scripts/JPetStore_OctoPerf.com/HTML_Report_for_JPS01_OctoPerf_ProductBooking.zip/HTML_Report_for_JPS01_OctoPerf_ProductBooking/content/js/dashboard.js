/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (Sec)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 85.29411764705883, "KoPercent": 14.705882352941176};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.78125, 2000, 3000, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 2000, 3000, "JPS01_T04_Login2/actions/Catalog.action-168"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T10_EnterDetails_&_Continue/actions/Order.action-214"], "isController": false}, {"data": [0.5, 2000, 3000, "JPS01_T14_Click_BookedOrder/actions/Order.action-225"], "isController": false}, {"data": [0.5, 2000, 3000, "JPS01_T11_Submit/actions/Order.action-215"], "isController": false}, {"data": [0.5, 2000, 3000, "JPS01_T04_Login"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T06_Select_A_SubPet/actions/Catalog.action-193"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T05_Select_A_Pet/actions/Catalog.action-192"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T15_SignOut2/actions/Catalog.action-229"], "isController": false}, {"data": [0.5, 2000, 3000, "JPS01_T14_Click_BookedOrder"], "isController": true}, {"data": [0.5, 2000, 3000, "JPS01_T04_Login1/actions/Account.action-167"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T15_SignOut"], "isController": true}, {"data": [0.0, 2000, 3000, "JPS01_T01_HomePage_Launch"], "isController": true}, {"data": [0.5, 2000, 3000, "JPS01_T13_Goto_MyOrders"], "isController": true}, {"data": [0.0, 2000, 3000, "JPS01_T01_HomePage_Launch/-146"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T10_EnterDetails_&_Continue"], "isController": true}, {"data": [0.5, 2000, 3000, "JPS01_T13_Goto_MyOrders/actions/Order.action-217"], "isController": false}, {"data": [0.5, 2000, 3000, "JPS01_T11_Submit"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T05_Select_A_Pet"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T08_Add_to_Cart"], "isController": true}, {"data": [0.5, 2000, 3000, "JPS01_T09_Proceed_to_Checkout"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T15_SignOut1/actions/Account.action-228"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T08_Add_to_Cart/actions/Cart.action-212"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T12_Goto_MyAccount"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T02_EnterStore/actions/Catalog.action-151"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T02_EnterStore"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T03_Click_SignIN"], "isController": true}, {"data": [1.0, 2000, 3000, "JPS01_T06_Select_A_SubPet"], "isController": true}, {"data": [0.5, 2000, 3000, "JPS01_T09_Proceed_to_Checkout/actions/Order.action-213"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T03_Click_SignIN/actions/Account.action;jsessionid=DF462579970A27BA23553BDDC12C3F55-166"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T12_Goto_MyAccount/actions/Account.action-216"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T07_Select_A_SubPet_Type/actions/Catalog.action-197"], "isController": false}, {"data": [1.0, 2000, 3000, "JPS01_T07_Select_A_SubPet_Type"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 170, 25, 14.705882352941176, 497.2823529411763, 210, 4222, 236.0, 475.30000000000007, 3782.8999999999987, 4222.0, 3.198314300227645, 16.555042900918103, 2.7331918000865425], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["JPS01_T04_Login2/actions/Catalog.action-168", 10, 0, 0.0, 236.5, 219, 254, 236.0, 253.8, 254.0, 254.0, 3.538570417551309, 6.284072562809625, 3.0133138711960368], "isController": false}, {"data": ["JPS01_T10_EnterDetails_&_Continue/actions/Order.action-214", 10, 0, 0.0, 240.0, 224, 260, 239.0, 259.2, 260.0, 260.0, 3.0562347188264063, 5.364229160299511, 4.357223697279951], "isController": false}, {"data": ["JPS01_T14_Click_BookedOrder/actions/Order.action-225", 10, 5, 50.0, 233.0, 217, 251, 235.5, 250.1, 251.0, 251.0, 2.42600679281902, 3.5451919577874818, 1.965207651018923], "isController": false}, {"data": ["JPS01_T11_Submit/actions/Order.action-215", 10, 5, 50.0, 343.29999999999995, 223, 497, 324.0, 494.9, 497.0, 497.0, 2.4248302618816684, 20.6333164100388, 1.9204466234238604], "isController": false}, {"data": ["JPS01_T04_Login", 10, 5, 50.0, 471.8, 437, 521, 466.5, 517.7, 521.0, 521.0, 3.249918752031199, 9.068669767630809, 6.629961204094898], "isController": true}, {"data": ["JPS01_T06_Select_A_SubPet/actions/Catalog.action-193", 10, 0, 0.0, 237.2, 221, 274, 233.5, 272.3, 274.0, 274.0, 3.033060357901122, 4.856450940248711, 2.523897198210494], "isController": false}, {"data": ["JPS01_T05_Select_A_Pet/actions/Catalog.action-192", 10, 0, 0.0, 236.4, 215, 280, 240.0, 276.8, 280.0, 280.0, 3.1416902293433866, 4.828201087810243, 2.5204087142632736], "isController": false}, {"data": ["JPS01_T15_SignOut2/actions/Catalog.action-229", 10, 0, 0.0, 241.5, 224, 272, 237.5, 270.8, 272.0, 272.0, 1.989258006763477, 3.6189343171871893, 1.577419435050726], "isController": false}, {"data": ["JPS01_T14_Click_BookedOrder", 10, 5, 50.0, 233.0, 217, 251, 235.5, 250.1, 251.0, 251.0, 2.42600679281902, 3.5451919577874818, 1.965207651018923], "isController": true}, {"data": ["JPS01_T04_Login1/actions/Account.action-167", 10, 5, 50.0, 235.29999999999998, 218, 269, 234.0, 267.0, 269.0, 269.0, 3.543586109142452, 3.5951480554571225, 4.2114690379163715], "isController": false}, {"data": ["JPS01_T15_SignOut", 10, 0, 0.0, 468.4, 437, 506, 468.5, 504.9, 506.0, 506.0, 1.9043991620643685, 3.9108994120167586, 3.0369959293467907], "isController": true}, {"data": ["JPS01_T01_HomePage_Launch", 10, 0, 0.0, 4024.2, 3646, 4222, 4094.5, 4222.0, 4222.0, 4222.0, 2.2376370552696354, 2.283526096442157, 1.4094491217274556], "isController": true}, {"data": ["JPS01_T13_Goto_MyOrders", 10, 5, 50.0, 791.9000000000001, 220, 1356, 815.5, 1355.0, 1356.0, 1356.0, 1.9212295869356388, 107.21811959654178, 1.532856027857829], "isController": true}, {"data": ["JPS01_T01_HomePage_Launch/-146", 10, 0, 0.0, 4024.2000000000003, 3646, 4222, 4094.5, 4222.0, 4222.0, 4222.0, 2.3685457129322596, 2.417119404310753, 1.491906235196589], "isController": false}, {"data": ["JPS01_T10_EnterDetails_&_Continue", 10, 0, 0.0, 240.0, 224, 260, 239.0, 259.2, 260.0, 260.0, 3.0553009471432935, 5.362590226856095, 4.35589243431103], "isController": true}, {"data": ["JPS01_T13_Goto_MyOrders/actions/Order.action-217", 10, 5, 50.0, 791.9000000000001, 220, 1356, 815.5, 1355.0, 1356.0, 1356.0, 1.9212295869356388, 107.21811959654178, 1.532856027857829], "isController": false}, {"data": ["JPS01_T11_Submit", 10, 5, 50.0, 343.29999999999995, 223, 497, 324.0, 494.9, 497.0, 497.0, 2.4254183846713557, 20.638320852534562, 1.9209124120785834], "isController": true}, {"data": ["JPS01_T05_Select_A_Pet", 10, 0, 0.0, 236.4, 215, 280, 240.0, 276.8, 280.0, 280.0, 3.1416902293433866, 4.828201087810243, 2.5204087142632736], "isController": true}, {"data": ["JPS01_T08_Add_to_Cart", 10, 0, 0.0, 231.4, 217, 246, 228.0, 245.9, 246.0, 246.0, 2.936857562408223, 5.657179240088106, 2.428356736417034], "isController": true}, {"data": ["JPS01_T09_Proceed_to_Checkout", 10, 5, 50.0, 241.1, 225, 277, 233.5, 276.7, 277.0, 277.0, 3.534817956875221, 6.99990610639802, 2.8823955019441496], "isController": true}, {"data": ["JPS01_T15_SignOut1/actions/Account.action-228", 10, 0, 0.0, 226.90000000000003, 210, 255, 226.0, 253.20000000000002, 255.0, 255.0, 1.993620414673046, 0.46725478468899523, 1.5984007426236044], "isController": false}, {"data": ["JPS01_T08_Add_to_Cart/actions/Cart.action-212", 10, 0, 0.0, 231.4, 217, 246, 228.0, 245.9, 246.0, 246.0, 2.936857562408223, 5.657179240088106, 2.428356736417034], "isController": false}, {"data": ["JPS01_T12_Goto_MyAccount", 10, 0, 0.0, 237.4, 217, 272, 234.0, 270.0, 272.0, 272.0, 1.9872813990461047, 4.641971072635135, 1.6107847277424483], "isController": true}, {"data": ["JPS01_T02_EnterStore/actions/Catalog.action-151", 10, 0, 0.0, 235.3, 219, 265, 230.5, 263.8, 265.0, 265.0, 4.887585532746823, 9.148471865835777, 3.412718413978495], "isController": false}, {"data": ["JPS01_T02_EnterStore", 10, 0, 0.0, 235.3, 219, 265, 230.5, 263.8, 265.0, 265.0, 4.885197850512945, 9.14400265632633, 3.411051233512457], "isController": true}, {"data": ["JPS01_T03_Click_SignIN", 10, 0, 0.0, 231.5, 214, 256, 229.5, 254.8, 256.0, 256.0, 3.734129947722181, 6.538738680918597, 3.085033140403286], "isController": true}, {"data": ["JPS01_T06_Select_A_SubPet", 10, 0, 0.0, 237.2, 221, 274, 233.5, 272.3, 274.0, 274.0, 3.0339805825242716, 4.857924378033981, 2.5246629437196604], "isController": true}, {"data": ["JPS01_T09_Proceed_to_Checkout/actions/Order.action-213", 10, 5, 50.0, 241.1, 225, 277, 233.5, 276.7, 277.0, 277.0, 3.536067892503536, 7.0023813207213585, 2.8834147365629423], "isController": false}, {"data": ["JPS01_T03_Click_SignIN/actions/Account.action;jsessionid=DF462579970A27BA23553BDDC12C3F55-166", 10, 0, 0.0, 231.5, 214, 256, 229.5, 254.8, 256.0, 256.0, 3.7369207772795217, 6.543625630605381, 3.08733884529148], "isController": false}, {"data": ["JPS01_T12_Goto_MyAccount/actions/Account.action-216", 10, 0, 0.0, 237.4, 217, 272, 234.0, 270.0, 272.0, 272.0, 1.986886548778065, 4.641048765646731, 1.6104646830915954], "isController": false}, {"data": ["JPS01_T07_Select_A_SubPet_Type/actions/Catalog.action-197", 10, 0, 0.0, 230.9, 216, 256, 229.5, 254.4, 256.0, 256.0, 3.1605562579013906, 5.0396057206068265, 2.6102367454171933], "isController": false}, {"data": ["JPS01_T07_Select_A_SubPet_Type", 10, 0, 0.0, 230.9, 216, 256, 229.5, 254.4, 256.0, 256.0, 3.1595576619273302, 5.038013428120063, 2.6094120260663507], "isController": true}]}, function(index, item){
        switch(index){
    // Errors pct, 3rd Column
            case 3:
                item = item.toFixed(2) + '%';
                break;
    // Average, 4th Column
            case 4:
		item = (item/1000).toFixed(2);
                break;
	// Min, 5th Column
            case 5:
		item = (item/1000).toFixed(2);
                break;
	// Max, 6th Column
            case 6:
		item = (item/1000).toFixed(2);
                break;
	// Median, 7th Column
            case 7:
		item = (item/1000).toFixed(2);
                break;
    // 90th pct, 8th Column
            case 8:
		item = (item/1000).toFixed(2);
                break;
	// 95th pct, 9th Column
            case 9:
		item = (item/1000).toFixed(2);
               	break;
	// 99th pct, 10th Column
            case 10:
		item = (item/1000).toFixed(2);
		break;
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
               	item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500", 10, 40.0, 5.882352941176471], "isController": false}, {"data": ["Test failed: text expected to contain /&lt;th colspan=2&gt;Payment Details&lt;/th&gt;/", 5, 20.0, 2.9411764705882355], "isController": false}, {"data": ["Test failed: code expected to contain /302/", 5, 20.0, 2.9411764705882355], "isController": false}, {"data": ["Test failed: text expected to contain /c_OrderID_NotFound/", 5, 20.0, 2.9411764705882355], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 170, 25, "500", 10, "Test failed: text expected to contain /&lt;th colspan=2&gt;Payment Details&lt;/th&gt;/", 5, "Test failed: code expected to contain /302/", 5, "Test failed: text expected to contain /c_OrderID_NotFound/", 5, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["JPS01_T14_Click_BookedOrder/actions/Order.action-225", 10, 5, "500", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["JPS01_T11_Submit/actions/Order.action-215", 10, 5, "500", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["JPS01_T04_Login1/actions/Account.action-167", 10, 5, "Test failed: code expected to contain /302/", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["JPS01_T13_Goto_MyOrders/actions/Order.action-217", 10, 5, "Test failed: text expected to contain /c_OrderID_NotFound/", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["JPS01_T09_Proceed_to_Checkout/actions/Order.action-213", 10, 5, "Test failed: text expected to contain /&lt;th colspan=2&gt;Payment Details&lt;/th&gt;/", 5, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
