/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = true;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "03_clicking_Flights_option-2"], "isController": false}, {"data": [1.0, 500, 1500, "05_choosing_from_Flights"], "isController": true}, {"data": [1.0, 500, 1500, "03_clicking_Flights_option-1"], "isController": false}, {"data": [1.0, 500, 1500, "05_choosing_from_Flights-0"], "isController": false}, {"data": [1.0, 500, 1500, "03_clicking_Flights_option-0"], "isController": false}, {"data": [1.0, 500, 1500, "09_LogOut-0"], "isController": false}, {"data": [1.0, 500, 1500, "08_choosing_First_BookedFlight_and_Cancelling_It-1"], "isController": false}, {"data": [1.0, 500, 1500, "09_LogOut-1"], "isController": false}, {"data": [1.0, 500, 1500, "04_ entering_Details_for_Finding_Flights"], "isController": true}, {"data": [1.0, 500, 1500, "07_clicking_Itinerary-2"], "isController": false}, {"data": [1.0, 500, 1500, "07_clicking_Itinerary-1"], "isController": false}, {"data": [1.0, 500, 1500, "07_clicking_Itinerary-0"], "isController": false}, {"data": [1.0, 500, 1500, "07_clicking_Itinerary"], "isController": true}, {"data": [1.0, 500, 1500, "03_clicking_Flights_option"], "isController": true}, {"data": [1.0, 500, 1500, "01_Launching_the_Page-1"], "isController": false}, {"data": [1.0, 500, 1500, "04_ entering_Details_for_Finding_Flights-0"], "isController": false}, {"data": [1.0, 500, 1500, "01_Launching_the_Page"], "isController": true}, {"data": [1.0, 500, 1500, "01_Launching_the_Page-0"], "isController": false}, {"data": [1.0, 500, 1500, "08_choosing_First_BookedFlight_and_Cancelling_It"], "isController": true}, {"data": [1.0, 500, 1500, "02_Login-1"], "isController": false}, {"data": [1.0, 500, 1500, "02_Login"], "isController": true}, {"data": [1.0, 500, 1500, "02_Login-2"], "isController": false}, {"data": [1.0, 500, 1500, "09_LogOut"], "isController": true}, {"data": [1.0, 500, 1500, "06_entering_Payment_Details_and_TicketBooked"], "isController": true}, {"data": [1.0, 500, 1500, "06_entering_Payment_Details_and_TicketBooked-0"], "isController": false}, {"data": [1.0, 500, 1500, "02_Login-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 29, 0, 0.0, 102.82758620689654, 82, 201, 116.0, 188.5, 201.0, 9.312780989081567, 21.484061396114324, 6.560906892260758], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["03_clicking_Flights_option-2", 3, 0, 0.0, 130.66666666666666, 86, 201, 201.0, 201.0, 201.0, 2.7149321266968323, 11.984763857466064, 1.6332013574660633], "isController": false}, {"data": ["05_choosing_from_Flights", 3, 0, 0.0, 106.33333333333333, 100, 115, 115.0, 115.0, 115.0, 2.690582959641256, 8.500035033632287, 2.282441143497758], "isController": true}, {"data": ["03_clicking_Flights_option-1", 3, 0, 0.0, 94.66666666666667, 94, 95, 95.0, 95.0, 95.0, 2.73972602739726, 4.67947345890411, 1.6454409246575343], "isController": false}, {"data": ["05_choosing_from_Flights-0", 3, 0, 0.0, 106.0, 100, 114, 114.0, 114.0, 114.0, 2.6929982046678638, 8.50766522666068, 2.284490013464991], "isController": false}, {"data": ["03_clicking_Flights_option-0", 3, 0, 0.0, 87.0, 82, 90, 90.0, 90.0, 90.0, 2.7548209366391188, 2.267884814049587, 1.646435950413223], "isController": false}, {"data": ["09_LogOut-0", 1, 0, 0.0, 90.0, 90, 90, 90.0, 90.0, 90.0, 11.11111111111111, 11.121961805555555, 6.586371527777778], "isController": false}, {"data": ["08_choosing_First_BookedFlight_and_Cancelling_It-1", 1, 0, 0.0, 98.0, 98, 98, 98.0, 98.0, 98.0, 10.204081632653061, 11.947943239795919, 8.709343112244898], "isController": false}, {"data": ["09_LogOut-1", 1, 0, 0.0, 93.0, 93, 93, 93.0, 93.0, 93.0, 10.752688172043012, 18.428679435483872, 5.313340053763441], "isController": false}, {"data": ["04_ entering_Details_for_Finding_Flights", 3, 0, 0.0, 103.0, 101, 105, 105.0, 105.0, 105.0, 1.4265335235378032, 3.77808487874465, 1.3582716654778886], "isController": true}, {"data": ["07_clicking_Itinerary-2", 1, 0, 0.0, 99.0, 99, 99, 99.0, 99.0, 99.0, 10.101010101010102, 75.62934027777777, 5.869239267676767], "isController": false}, {"data": ["07_clicking_Itinerary-1", 1, 0, 0.0, 93.0, 93, 93, 93.0, 93.0, 93.0, 10.752688172043012, 18.365675403225808, 6.426411290322581], "isController": false}, {"data": ["07_clicking_Itinerary-0", 1, 0, 0.0, 90.0, 90, 90, 90.0, 90.0, 90.0, 11.11111111111111, 8.875868055555555, 6.618923611111112], "isController": false}, {"data": ["07_clicking_Itinerary", 1, 0, 0.0, 283.0, 283, 283, 283.0, 283.0, 283.0, 3.5335689045936394, 35.31498454063605, 6.270014355123675], "isController": true}, {"data": ["03_clicking_Flights_option", 3, 0, 0.0, 313.6666666666667, 271, 387, 387.0, 387.0, 387.0, 2.3382696804364773, 16.240774795401403, 4.208428731488699], "isController": true}, {"data": ["01_Launching_the_Page-1", 1, 0, 0.0, 116.0, 116, 116, 116.0, 116.0, 116.0, 8.620689655172413, 14.74104256465517, 4.2850889008620685], "isController": false}, {"data": ["04_ entering_Details_for_Finding_Flights-0", 3, 0, 0.0, 101.0, 99, 103, 103.0, 103.0, 103.0, 1.4278914802475011, 3.7816813422179916, 1.3595646418372205], "isController": false}, {"data": ["01_Launching_the_Page", 1, 0, 0.0, 295.0, 295, 295, 295.0, 295.0, 295.0, 3.389830508474576, 9.19292902542373, 3.234242584745763], "isController": true}, {"data": ["01_Launching_the_Page-0", 1, 0, 0.0, 176.0, 176, 176, 176.0, 176.0, 176.0, 5.681818181818182, 5.692915482954546, 2.5967684659090913], "isController": false}, {"data": ["08_choosing_First_BookedFlight_and_Cancelling_It", 1, 0, 0.0, 98.0, 98, 98, 98.0, 98.0, 98.0, 10.204081632653061, 11.947943239795919, 8.709343112244898], "isController": true}, {"data": ["02_Login-1", 1, 0, 0.0, 97.0, 97, 97, 97.0, 97.0, 97.0, 10.309278350515465, 17.608327963917525, 6.181539948453608], "isController": false}, {"data": ["02_Login", 1, 0, 0.0, 278.0, 278, 278, 278.0, 278.0, 278.0, 3.5971223021582737, 13.201157823741006, 6.888629721223021], "isController": true}, {"data": ["02_Login-2", 1, 0, 0.0, 95.0, 95, 95, 95.0, 95.0, 95.0, 10.526315789473683, 11.903782894736842, 6.2602796052631575], "isController": false}, {"data": ["09_LogOut", 1, 0, 0.0, 185.0, 185, 185, 185.0, 185.0, 185.0, 5.405405405405405, 14.67483108108108, 5.875211148648649], "isController": true}, {"data": ["06_entering_Payment_Details_and_TicketBooked", 3, 0, 0.0, 97.66666666666667, 87, 105, 105.0, 105.0, 105.0, 2.7598896044158234, 7.709183820147194, 2.8021144779208833], "isController": true}, {"data": ["06_entering_Payment_Details_and_TicketBooked-0", 3, 0, 0.0, 97.66666666666667, 87, 105, 105.0, 105.0, 105.0, 2.7598896044158234, 7.709183820147194, 2.8021144779208833], "isController": false}, {"data": ["02_Login-0", 1, 0, 0.0, 84.0, 84, 84, 84.0, 84.0, 84.0, 11.904761904761903, 9.893508184523808, 8.579799107142856], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 29, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
